from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Boolean, Text
from sqlalchemy.orm import relationship
from .database import Base
from datetime import datetime

class Warehouse(Base):
    __tablename__ = "warehouses"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    location = Column(String)
    capacity = Column(Integer)
    
class SKU(Base):
    __tablename__ = "skus"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True)
    category = Column(String)
    unit_price = Column(Float)

class Inventory(Base):
    __tablename__ = "inventory"
    id = Column(Integer, primary_key=True, index=True)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id"))
    sku_id = Column(Integer, ForeignKey("skus.id"))
    quantity = Column(Integer)
    
class PhotoRecord(Base):
    __tablename__ = "photo_records"
    id = Column(Integer, primary_key=True, index=True)
    image_path = Column(String)
    detected_sku = Column(String)
    detected_qty = Column(Integer)
    expiry_date = Column(String)
    is_damaged = Column(Boolean)
    damage_score = Column(Float)
    ai_explanation = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)