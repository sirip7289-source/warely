from ortools.linear_solver import pywraplp
import google.generativeai as genai
import os

genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

# Mock data for warehouses and costs (This would normally come from the database)
MOCK_WAREHOUSES = {
    1: {"name": "Warehouse_A", "inventory": 1500, "demand": 1200, "capacity": 2000},
    2: {"name": "Warehouse_B", "inventory": 500, "demand": 1000, "capacity": 1500},
    3: {"name": "Warehouse_C", "inventory": 2000, "demand": 800, "capacity": 2500},
}

MOCK_COSTS = {
    (1, 2): 2.5, (1, 3): 1.0,
    (2, 1): 2.5, (2, 3): 3.0,
    (3, 1): 1.0, (3, 2): 3.0,
}

def calculate_rebalancing_plan():
    """Calculates the optimal stock transfer plan using Linear Programming."""
    solver = pywraplp.Solver.CreateSolver('GLOP')
    
    if not solver:
        return {"error": "Solver not available"}

    warehouses = MOCK_WAREHOUSES
    
    # 1. Define Transfer Variables: x[i, j] = amount to move from warehouse i to j
    transfers = {}
    for i in warehouses:
        for j in warehouses:
            if i != j:
                # Max transfer amount is the source inventory
                max_transfer = warehouses[i]['inventory'] 
                transfers[(i, j)] = solver.NumVar(0, max_transfer, f'tr_{i}_{j}')

    # 2. Objective Function: Minimize Cost
    objective = solver.Objective()
    for (i, j), var in transfers.items():
        cost = MOCK_COSTS.get((i, j), 10.0)
        objective.SetCoefficient(var, cost)
    objective.SetMinimization()

    # 3. Constraints: Balance Supply and Demand
    for w_id, w_data in warehouses.items():
        # Inventory after transfers must meet demand and stay within capacity
        
        # Total flow out (from w_id to others)
        flow_out = sum(transfers.get((w_id, j), 0) for j in warehouses if j != w_id)
        
        # Total flow in (to w_id from others)
        flow_in = sum(transfers.get((i, w_id), 0) for i in warehouses if i != w_id)
        
        final_inventory = w_data['inventory'] - flow_out + flow_in
        
        # Constraint A: Final inventory must be >= Demand (Service Level)
        solver.Add(final_inventory >= w_data['demand'], name=f'demand_{w_id}')
        
        # Constraint B: Final inventory must be <= Capacity
        solver.Add(final_inventory <= w_data['capacity'], name=f'capacity_{w_id}')

    # 4. Solve
    status = solver.Solve()
    
    results = []
    total_cost = 0
    
    if status == pywraplp.Solver.OPTIMAL:
        for (i, j), var in transfers.items():
            amount = var.solution_value()
            if amount > 0.01: # Check for non-zero transfer
                source_name = warehouses[i]['name']
                dest_name = warehouses[j]['name']
                cost = MOCK_COSTS.get((i, j), 10.0)
                results.append({
                    "from": source_name,
                    "to": dest_name,
                    "amount": amount,
                    "cost": amount * cost
                })
                total_cost += amount * cost
    
    return results, total_cost

def get_ai_explanation_for_optimization(transfers, total_cost):
    """Uses Gemini to explain the calculated transfer plan."""
    
    if not transfers:
        return "The optimization engine determined that current inventory levels are adequate to meet demand and capacity constraints across all warehouses, so no transfers are necessary."

    transfer_summary = "\n".join([
        f"- Move {int(t['amount'])} units from {t['from']} to {t['to']} (Cost: ${t['cost']:.2f})"
        for t in transfers
    ])
    
    system_prompt = "You are a supply chain assistant. Using ONLY the provided data about the optimal transfer plan, generate a concise, single-paragraph summary explaining why the transfers are being made and what the total cost is. Do not guess or invent new data."
    user_query = f"""
    The following optimal stock transfer plan was generated to minimize cost while meeting demand and capacity constraints:

    Total Cost: ${total_cost:.2f}
    Transfers:
    {transfer_summary}
    """
    
    model = genai.GenerativeModel('gemini-2.5-flash')
    response = model.generate_content(
        user_query,
        system_instruction=system_prompt
    )
    
    return response.text

def run_optimization_service():
    """Main function to run optimization and get explanation."""
    transfers, total_cost = calculate_rebalancing_plan()
    explanation = get_ai_explanation_for_optimization(transfers, total_cost)
    
    return {
        "transfers": transfers,
        "total_cost": total_cost,
        "ai_explanation": explanation
    }