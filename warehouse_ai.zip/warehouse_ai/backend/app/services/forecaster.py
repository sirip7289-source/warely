import pandas as pd
import numpy as np
from prophet import Prophet
import google.generativeai as genai
import os

# Configure Gemini
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

def generate_synthetic_data(product_name: str) -> pd.DataFrame:
    """Generates synthetic sales data simulating seasonality and trends."""
    np.random.seed(hash(product_name) % 100)
    
    # Generate 3 years of daily data
    days = 365 * 3
    dates = pd.date_range(end=pd.Timestamp.now().date(), periods=days, freq='D')
    
    # Base trend
    base_sales = 50 + np.arange(days) * 0.05
    
    # Weekly seasonality (e.g., higher sales on weekends)
    weekly_seasonality = np.sin(2 * np.pi * dates.dayofweek / 7) * 5
    
    # Yearly seasonality (e.g., higher sales in winter for "Winter Jackets")
    yearly_seasonality = np.sin(2 * np.pi * dates.dayofyear / 365) * 20
    
    # Noise
    noise = np.random.normal(0, 10, days)
    
    # Final sales data
    sales = (base_sales + weekly_seasonality + yearly_seasonality + noise).clip(min=10).astype(int)
    
    df = pd.DataFrame({'ds': dates, 'y': sales})
    return df

def run_forecast(product_name: str):
    """Generates forecast using Prophet and gets Gemini explanation."""
    
    # 1. Generate or Fetch Historical Data
    df_history = generate_synthetic_data(product_name)
    
    # 2. Train Prophet Model
    m = Prophet(yearly_seasonality=True, weekly_seasonality=True)
    m.fit(df_history)
    
    # 3. Predict next 90 days
    future = m.make_future_dataframe(periods=90)
    forecast = m.predict(future)
    
    # 4. Prepare data for front-end chart
    chart_data = []
    # Only show the last 90 days of history and the 90 days of forecast
    chart_df = forecast.tail(180).copy()
    
    for index, row in chart_df.iterrows():
        is_actual = row['ds'] < pd.Timestamp.now().date()
        
        chart_data.append({
            "name": row['ds'].strftime('%m-%d'),
            "actual": int(df_history[df_history['ds'] == row['ds']]['y'].iloc[0]) if is_actual and not df_history[df_history['ds'] == row['ds']].empty else None,
            "predicted": int(row['yhat'].clip(lower=0)) # Predicted sales
        })
    
    # 5. Get AI Explanation
    forecast_details = {
        "product": product_name,
        "history_span": f"{df_history['ds'].min().strftime('%Y-%m-%d')} to {df_history['ds'].max().strftime('%Y-%m-%d')}",
        "average_sales_units": int(df_history['y'].mean()),
        "predicted_demand_next_90_days": int(forecast.tail(90)['yhat'].sum()),
        "trend_summary": "The sales data shows a strong upward trend with clear seasonal peaks in Q4 and Q1."
    }
    
    system_prompt = "You are a supply chain assistant. Using ONLY the provided numbers and extracted details, generate a concise, single-paragraph explanation for the demand forecast. Do not guess or invent new data."
    user_query = f"""
    Generate a forecast explanation using this data:
    Product: {forecast_details['product']}
    Historical Data Span: {forecast_details['history_span']}
    Avg Daily Sales: {forecast_details['average_sales_units']} units
    Predicted Total Demand (Next 90 Days): {forecast_details['predicted_demand_next_90_days']} units
    Trend Observation: {forecast_details['trend_summary']}
    """
    
    model = genai.GenerativeModel('gemini-2.5-flash')
    response = model.generate_content(
        user_query,
        system_instruction=system_prompt
    )
    
    return {
        "forecast_data": chart_data,
        "explanation": response.text
    }