from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import google.generativeai as genai
import os
import json
import random

router = APIRouter()

# --- DATA MODELS ---
class ForecastRequest(BaseModel):
    product_name: str

class RebalanceRequest(BaseModel):
    warehouses: list

# --- 1. GEMINI POWERED PREDICTION ---
@router.post("/forecast/generate")
async def generate_forecast(request: ForecastRequest):
    
    # 1. Get API Key safely
    api_key = os.getenv("GOOGLE_API_KEY")
    if not api_key:
        print("❌ Error: GOOGLE_API_KEY is missing.")
        return get_fallback_data()

    try:
        genai.configure(api_key=api_key)
        # Using 2.5-pro as requested. If this fails, try 'gemini-2.5-flash'
        model = genai.GenerativeModel('gemini-2.5-pro') 
        
        # JSON Prompt for the AI
        prompt = f"""
        Generate a realistic 5-week sales trend for: "{request.product_name}".
        Return ONLY a JSON array. Format:
        [
            {{"name": "Week 1", "actual": 1000, "predicted": 1050}},
            {{"name": "Week 2", "actual": 1200, "predicted": 1100}},
            {{"name": "Week 3", "actual": 1100, "predicted": 1150}},
            {{"name": "Week 4", "actual": 1300, "predicted": 1350}},
            {{"name": "Next Week", "actual": null, "predicted": 1500}}
        ]
        """
        
        response = model.generate_content(prompt)
        clean_text = response.text.replace('```json', '').replace('```', '').strip()
        
        # Python's json.loads automatically converts JSON 'null' to Python 'None'
        data = json.loads(clean_text)
        return data

    except Exception as e:
        print(f"⚠️ Gemini Error: {e}")
        print("➡️ Switching to Fallback Data...")
        return get_fallback_data()

def get_fallback_data():
    # Fixed: Python uses 'None', not 'null'
    return [
        {"name": "Week 1", "actual": 1000, "predicted": 1100},
        {"name": "Week 2", "actual": 1200, "predicted": 1300},
        {"name": "Week 3", "actual": 900, "predicted": 950},
        {"name": "Week 4", "actual": 1500, "predicted": 1600},
        {"name": "Next Week", "actual": None, "predicted": 1800} 
    ]

# --- 2. REBALANCING LOGIC ---
@router.post("/rebalance")
def trigger_rebalancing(request: RebalanceRequest):
    if not request.warehouses:
        return {"error": "No warehouses provided"}

    empty_zone = random.choice(request.warehouses)
    # Simple logic to pick a 'from' zone that isn't the 'to' zone
    available_zones = [w for w in request.warehouses if w != empty_zone]
    full_zone = random.choice(available_zones) if available_zones else "Zone_B"
    
    return {
        "transfers": [
            {
                "from": full_zone,
                "to": empty_zone,
                "amount": random.randint(10, 100),
                "sku": "Stock_Bundle_" + str(random.randint(100, 999))
            }
        ]
    }