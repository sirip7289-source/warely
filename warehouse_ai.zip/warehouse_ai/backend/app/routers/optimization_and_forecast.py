from fastapi import APIRouter
from pydantic import BaseModel
from app.services.forecaster import run_forecast
from app.services.optimizer import run_optimization_service
router = APIRouter(
    tags=["AI Core"]
)

class ForecastRequest(BaseModel):
    product_name: str

@router.post("/forecast/generate")
def generate_demand_forecast(request: ForecastRequest):
    """Generates demand forecast chart data and Gemini explanation."""
    return run_forecast(request.product_name)

@router.post("/rebalance/suggest")
def suggest_rebalancing_plan():
    """Calculates and suggests an optimal stock transfer plan."""
    return run_optimization_service()