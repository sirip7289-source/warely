# Update your existing imports to include File, UploadFile, and random
from fastapi import FastAPI, File, UploadFile
from pydantic import BaseModel
from typing import List
import random # Needed for the simulation
from fastapi.middleware.cors import CORSMiddleware
app = FastAPI()

# --- 1. Define Data Models (Matches what your frontend expects) ---
class InventoryItem(BaseModel):
    warehouse: str
    sku: str
    quantity: int

class Warehouse(BaseModel):
    id: int
    name: str
    location: str
    capacity: int

class SKU(BaseModel):
    id: int
    name: str
    category: str
    unit_price: float
class ForecastRequest(BaseModel):
    product_name: str

@app.post("/forecast/generate")
async def generate_forecast(request: ForecastRequest):
    # Simulating 5 months of prediction data
    return {
        "forecast_data": [
            {"name": "Jan", "actual": 400, "predicted": 420},
            {"name": "Feb", "actual": 300, "predicted": 310},
            {"name": "Mar", "actual": 200, "predicted": 250},
            {"name": "Apr", "actual": 278, "predicted": 290},
            {"name": "May", "actual": 189, "predicted": 200},
        ],
        "explanation": f"Projected 5% growth for '{request.product_name}' based on seasonal trends."
    }
class CreateWarehouseModel(BaseModel):
    name: str
    location: str
    capacity: int

class CreateSKUModel(BaseModel):
    name: str
    category: str
    unit_price: float

class UpdateStockModel(BaseModel):
    sku_id: int
    warehouse_id: int
    quantity: int

# In-memory storage (Reset every time you restart the server)
# In a real app, this would be a database.
warehouses_db = []
skus_db = []
inventory_db = []

@app.post("/inventory/warehouses")
async def create_warehouse(warehouse: CreateWarehouseModel):
    new_id = len(warehouses_db) + 1
    entry = {
        "id": new_id, 
        "name": warehouse.name, 
        "location": warehouse.location, 
        "capacity": warehouse.capacity
    }
    warehouses_db.append(entry)
    return entry

@app.post("/inventory/skus")
async def create_sku(sku: CreateSKUModel):
    new_id = len(skus_db) + 1
    entry = {
        "id": new_id, 
        "name": sku.name, 
        "category": sku.category, 
        "unit_price": sku.unit_price
    }
    skus_db.append(entry)
    return entry

@app.post("/inventory/stock/update")
async def update_stock(update: UpdateStockModel):
    # Find if this specific stock record already exists
    found = False
    current_qty = 0
    
    # Search for existing record to update
    for item in inventory_db:
        if item["warehouse_id"] == update.warehouse_id and item["sku_id"] == update.sku_id:
            item["quantity"] += update.quantity
            current_qty = item["quantity"]
            found = True
            break
    
    # If not found, create a new record
    if not found:
        # For display purposes, we need the names. In a real DB, we'd join tables.
        # Here we just find the names from our simple lists:
        w_name = next((w["name"] for w in warehouses_db if w["id"] == update.warehouse_id), "Unknown Warehouse")
        s_name = next((s["name"] for s in skus_db if s["id"] == update.sku_id), "Unknown SKU")
        
        new_record = {
            "warehouse": w_name,
            "warehouse_id": update.warehouse_id,
            "sku": s_name,
            "sku_id": update.sku_id,
            "quantity": update.quantity
        }
        inventory_db.append(new_record)
        current_qty = update.quantity

    return {"status": "success", "current_quantity": current_qty}

# --- UPDATE EXISTING GET ROUTES TO USE THESE LISTS ---
# Replace your old fixed GET functions with these dynamic ones so you can see your changes.

@app.get("/inventory/warehouses", response_model=List[Warehouse])
def get_warehouses():
    return warehouses_db

@app.get("/inventory/skus", response_model=List[SKU])
def get_skus():
    return skus_db

@app.get("/inventory/levels")
def get_inventory_levels():
    return inventory_db
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins (simplest for development)
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)
# --- 5. Optimization Route ---
class RebalanceRequest(BaseModel):
    sku_id: int
    target_service_level: float

@app.post("/rebalance/suggest")
async def suggest_rebalance(request: RebalanceRequest):
    return {
        "transfers": [
            {"from": "Main Hub", "to": "East Side", "amount": 50},
            {"from": "West Coast", "to": "Main Hub", "amount": 20}
        ],
        "ai_explanation": "Optimization Engine recommends moving stock to 'East Side' to prevent stockouts."
    }
# --- 2. Add the Missing Routes ---
@app.post("/upload/photo")
async def analyze_photo(file: UploadFile = File(...)):
    # Simulating AI analysis (Gemini Mock)
    return {
        "detected_sku": "SKU-101-Winter",
        "detected_qty": random.randint(5, 50),
        "is_damaged": random.choice([True, False]),
        "expiry_date": "2025-12-01",
        "damage_score": round(random.random(), 2),
        "ai_explanation": "Analysis Complete: Identified standard packaging. Barcode visible. (Simulation)"
    }
@app.get("/inventory/levels", response_model=List[InventoryItem])
def get_inventory_levels():
    # Returns dummy data so the frontend has something to show
    return [
        {"warehouse": "Main Hub", "sku": "Winter Jacket", "quantity": 150},
        {"warehouse": "East Side", "sku": "Running Shoes", "quantity": 85},
        {"warehouse": "Main Hub", "sku": "Gloves", "quantity": 15} # Low stock example
    ]

@app.get("/inventory/warehouses", response_model=List[Warehouse])
def get_warehouses():
    return [
        {"id": 1, "name": "Main Hub", "location": "New York", "capacity": 1000},
        {"id": 2, "name": "East Side", "location": "Boston", "capacity": 500}
    ]

@app.get("/inventory/skus", response_model=List[SKU])
def get_skus():
    return [
        {"id": 1, "name": "Winter Jacket", "category": "Apparel", "unit_price": 120.50},
        {"id": 2, "name": "Running Shoes", "category": "Footwear", "unit_price": 89.99}
    ]