import React from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Package, UploadCloud, TrendingUp, Box } from 'lucide-react';

// Import pages
import DashboardPage from './pages/DashboardPage';
import InventoryPage from './pages/InventoryPage';
import UploadPage from './pages/UploadPage';
import ForecastPage from './pages/ForecastPage';

// --- 1. Modern Sidebar Component ---
const Sidebar: React.FC = () => {
    return (
        <div className="w-64 bg-slate-900 text-white flex flex-col h-full shadow-xl z-10">
            {/* Logo Area */}
            <div className="p-6 flex items-center gap-3 mb-4">
                <div className="bg-indigo-500 p-2 rounded-lg">
                    <Box className="text-white" size={24} />
                </div>
                <div>
                    <h1 className="text-lg font-bold tracking-wide">Hackathon<span className="text-indigo-400">AI</span></h1>
                    <p className="text-xs text-slate-400">Al-Based Warehouse Optimization System</p>
                </div>
            </div>

            {/* Navigation */}
            <nav className="flex-1 px-4 space-y-2">
                <NavLink to="/" icon={<LayoutDashboard size={20} />} label="Overview" />
                <NavLink to="/inventory" icon={<Package size={20} />} label="Inventory" />
                <NavLink to="/forecast" icon={<TrendingUp size={20} />} label="Intelligence" />
                <NavLink to="/upload" icon={<UploadCloud size={20} />} label="Visual Scanner" />
            </nav>

            {/* Footer User Profile (Fake) */}
            <div className="p-4 border-t border-slate-800">
                <div className="flex items-center gap-3 px-2">
                    <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center font-bold text-xs">TQC</div>
                    <div className="text-sm">
                        <p className="font-medium">The Quad Crew </p>
                        <p className="text-xs text-slate-400">Ai And Data Analyst Batch 2nd Year</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

const NavLink: React.FC<{ to: string, icon: JSX.Element, label: string }> = ({ to, icon, label }) => {
    const location = useLocation();
    const isActive = location.pathname === to;

    return (
        <Link 
            to={to} 
            className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 group ${
                isActive 
                ? "bg-indigo-600/10 text-indigo-400 border-l-2 border-indigo-500" 
                : "text-slate-400 hover:bg-slate-800 hover:text-white"
            }`}
        >
            <span className={isActive ? "text-indigo-400" : "group-hover:text-white"}>{icon}</span>
            <span className="text-sm font-medium">{label}</span>
        </Link>
    );
};

export default function App() {
    return (
        <BrowserRouter>
            <div className="flex h-screen overflow-hidden">
                <Sidebar />
                <main className="flex-1 overflow-y-auto bg-slate-50/50 relative">
                    {/* Top Header Bar */}
                    <div className="sticky top-0 z-20 bg-white/80 backdrop-blur-md border-b border-slate-200 px-8 py-4 flex justify-between items-center">
                        <h2 className="text-xl font-semibold text-slate-800">Warehouse Operations</h2>
                        <span className="text-xs font-mono bg-slate-100 px-2 py-1 rounded text-slate-500">v2.0.1 Live</span>
                    </div>
                    
                    <div className="p-8 max-w-7xl mx-auto">
                        <Routes>
                            <Route path="/" element={<DashboardPage />} />
                            <Route path="/inventory" element={<InventoryPage />} />
                            <Route path="/forecast" element={<ForecastPage />} />
                            <Route path="/upload" element={<UploadPage />} />
                        </Routes>
                    </div>
                </main>
            </div>
        </BrowserRouter>
    );
}