import React, { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { TrendingUp, Package, Warehouse, Zap } from 'lucide-react';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

const KPI_Card: React.FC<{ title: string, value: string | number, icon: JSX.Element, color: string }> = ({ title, value, icon, color }) => (
    <div className="bg-white p-6 rounded-xl shadow-lg border-l-4" style={{ borderColor: color }}>
        <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-gray-500">{title}</p>
            {React.cloneElement(icon, { size: 24, className: `text-${color.replace('#', 'text-')}-500` })}
        </div>
        <p className="text-3xl font-bold text-gray-900 mt-1">{value}</p>
    </div>
);

export default function DashboardPage() {
    const [inventoryData, setInventoryData] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchData = async () => {
        setLoading(true);
        try {
            const res = await fetch(`${API_URL}/inventory/levels`);
            const data = await res.json();
            setInventoryData(data);
        } catch (error) {
            console.error("Failed to fetch dashboard data:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    // --- Data Aggregation for Charts and KPIs ---
    
    // Aggregate total units and group by SKU
    const totalUnits = inventoryData.reduce((sum, item) => sum + item.quantity, 0);
    const aggregatedBySku = inventoryData.reduce((acc, item) => {
        if (!acc[item.sku]) {
            acc[item.sku] = 0;
        }
        acc[item.sku] += item.quantity;
        return acc;
    }, {});
    
    // Simple low stock simulation (for demo KPI)
    const lowStockAlerts = inventoryData.filter(item => item.quantity < 100).length;

    const chartData = {
        labels: Object.keys(aggregatedBySku),
        datasets: [
            {
                label: 'Total Stock Quantity',
                data: Object.values(aggregatedBySku),
                backgroundColor: 'rgba(59, 130, 246, 0.6)',
                borderColor: 'rgba(59, 130, 246, 1)',
                borderWidth: 1,
            },
        ],
    };

    const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top' as const,
            },
            title: {
                display: true,
                text: 'Overall SKU Stock Levels Across All Warehouses',
            },
        },
        scales: {
            y: {
                beginAtZero: true
            }
        }
    };

    if (loading) {
        return <div className="text-center py-12 text-gray-500">Loading Dashboard...</div>
    }

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-gray-800 flex items-center"><TrendingUp className="mr-3"/> Global Operations Dashboard</h1>
            
            {/* KPI Section */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <KPI_Card 
                    title="Total Stock Units" 
                    value={totalUnits.toLocaleString()} 
                    icon={<Package />} 
                    color="#10B981" // Green
                />
                <KPI_Card 
                    title="Unique SKUs Tracked" 
                    value={Object.keys(aggregatedBySku).length} 
                    icon={<Warehouse />} 
                    color="#3B82F6" // Blue
                />
                <KPI_Card 
                    title="Active Warehouses" 
                    value={3} // Hardcoded for now, waiting for warehouse CRUD logic to fully integrate
                    icon={<Warehouse />} 
                    color="#8B5CF6" // Purple
                />
                <KPI_Card 
                    title="Low Stock Alerts" 
                    value={lowStockAlerts} 
                    icon={<Zap />} 
                    color="#EF4444" // Red
                />
            </div>

            {/* Inventory Chart */}
            <div className="bg-white p-6 rounded-xl shadow-lg">
                <h2 className="text-xl font-semibold mb-4 text-gray-700">Stock Breakdown by Product (SKU)</h2>
                <div className="h-[400px] w-full">
                    <Bar data={chartData} options={options} />
                </div>
            </div>
        </div>
    );
}