import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Truck, UploadCloud } from 'lucide-react';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

export default function ForecastPage() {
    // State for AI Vision (kept separate for display)
    const [file, setFile] = useState<File | null>(null);
    const [result, setResult] = useState<any>(null);
    const [loading, setLoading] = useState(false);
    
    // State for Prediction
    const [productName, setProductName] = useState("Winter Jackets"); // Default
    const [predictionData, setPredictionData] = useState<any[]>([]);
    const [predicting, setPredicting] = useState(false);
    const [forecastExplanation, setForecastExplanation] = useState("");

    // State for Optimization
    const [optimizing, setOptimizing] = useState(false);
    const [rebalancePlan, setRebalancePlan] = useState<any[] | null>(null);
    const [rebalanceExplanation, setRebalanceExplanation] = useState("");

    // --- 1. AI FORECAST FUNCTION (Updated to use new API endpoint) ---
    const handleForecast = async () => {
        setPredicting(true);
        setForecastExplanation("Analyzing sales data and market trends with Gemini...");
        
        try {
            const res = await fetch(`${API_URL}/forecast/generate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ product_name: productName })
            });
            const data = await res.json();
            
            // Assuming the backend returns { forecast_data: [...], explanation: "..." }
            setPredictionData(data.forecast_data || []);
            setForecastExplanation(data.explanation || "Forecast generated successfully.");

        } catch (err) {
            console.error(err);
            setForecastExplanation("Error generating forecast.");
        }
        setPredicting(false);
    };

    // Load initial forecast on start
    useEffect(() => {
        handleForecast();
    }, []);

    // --- 2. AI VISION FUNCTION (Uses existing backend endpoint) ---
    const handleUpload = async () => {
        if (!file) return;
        setLoading(true);
        const formData = new FormData();
        formData.append('file', file);
        try {
            const res = await fetch(`${API_URL}/upload/photo`, { method: 'POST', body: formData });
            const data = await res.json();
            setResult(data);
        } catch (err) { console.error(err); }
        setLoading(false);
    };

    // --- 3. OPTIMIZATION FUNCTION (Updated to use new API endpoint) ---
    const handleOptimize = async () => {
        setOptimizing(true);
        setRebalanceExplanation("Calculating optimal transfer plan using OR-Tools and Gemini...");
        try {
            const res = await fetch(`${API_URL}/rebalance/suggest`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                // Dummy body - backend logic should handle the rest
                body: JSON.stringify({ sku_id: 1, target_service_level: 0.95 })
            });
            const data = await res.json(); 
            setRebalancePlan(data.transfers || []);
            setRebalanceExplanation(data.ai_explanation || "Optimization complete.");
        } catch (err) { 
            console.error(err); 
            setRebalanceExplanation("Error calculating optimization plan.");
        }
        setOptimizing(false);
    };

    return (
        <div className="p-4 font-sans text-gray-800">
            <header className="mb-8 border-b pb-4">
                <h1 className="text-3xl font-extrabold text-blue-900 tracking-tight flex items-center"><TrendingUp className="mr-3" /> Demand & Optimization Center</h1>
                <p className="text-gray-600 mt-2">Simulate forecasts and generate optimal stock rebalancing plans.</p>
            </header>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                {/* ---------------- SECTION 1: AI VISION ---------------- */}
                <div className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-blue-500 h-fit lg:col-span-1">
                    <h2 className="text-xl font-bold mb-4 flex items-center text-blue-700">
                        <UploadCloud className="mr-2 h-5 w-5" /> Inbound Scanner
                    </h2>
                    <p className="text-sm text-gray-500 mb-4">Use Gemini Vision to instantly log incoming stock details.</p>
                    <div className="space-y-4">
                        <input 
                            type="file" 
                            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFile(e.target.files ? e.target.files[0] : null)}
                            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                        />
                        <button 
                            onClick={handleUpload}
                            disabled={loading || !file}
                            className="w-full bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition font-medium shadow-md disabled:opacity-50"
                        >
                            {loading ? "Analyzing..." : "Analyze Incoming Stock"}
                        </button>
                    </div>
                    {result && (
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-6 p-4 rounded-lg bg-gray-50 border border-blue-100">
                            <div className="grid grid-cols-2 gap-4 mb-4">
                                <div><span className="text-xs text-gray-500 uppercase font-bold">SKU</span><p className="text-lg font-bold text-gray-900">{result.detected_sku}</p></div>
                                <div><span className="text-xs text-gray-500 uppercase font-bold">QTY</span><p className="text-lg font-bold text-gray-900">{result.detected_qty}</p></div>
                            </div>
                            <div className={`p-3 rounded border-l-4 ${result.is_damaged ? "bg-red-50 border-red-500 text-red-700" : "bg-green-50 border-green-500 text-green-700"}`}>
                                <p className="font-bold">{result.is_damaged ? "⚠️ QUARANTINE" : "✅ APPROVED"}</p>
                                <p className="text-sm mt-1">{result.ai_explanation}</p>
                            </div>
                        </motion.div>
                    )}
                </div>

                {/* ---------------- SECTION 2: DEMAND PREDICTION ---------------- */}
                <div className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-purple-500 lg:col-span-2">
                    <h2 className="text-xl font-bold mb-4 text-purple-700">📈 Smart Demand Forecast</h2>
                    
                    <div className="flex gap-2 mb-4">
                        <input 
                            type="text" 
                            value={productName}
                            onChange={(e) => setProductName(e.target.value)}
                            placeholder="Enter Product SKU/Name"
                            className="flex-1 border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
                        />
                        <button 
                            onClick={handleForecast}
                            disabled={predicting}
                            className="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition font-medium disabled:opacity-50"
                        >
                            {predicting ? "Predicting..." : "Generate Forecast"}
                        </button>
                    </div>

                    <div className="h-72 w-full mb-4">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={predictionData}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                                <YAxis axisLine={false} tickLine={false} />
                                <Tooltip contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}} />
                                <Legend />
                                <Line type="monotone" dataKey="actual" stroke="#94a3b8" name="Actual Sales" strokeWidth={3} dot={{r: 4}} />
                                <Line type="monotone" dataKey="predicted" stroke="#8b5cf6" name="AI Forecast" strokeWidth={3} strokeDasharray="5 5" dot={{r: 4}} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                    <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg text-sm text-purple-800 italic">
                        <span className="font-bold">Gemini Insight:</span> {forecastExplanation}
                    </div>
                </div>

                {/* ---------------- SECTION 3: OPTIMIZATION ---------------- */}
                <div className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-green-500 lg:col-span-3">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold text-green-700 flex items-center"><Truck className="mr-2 h-5 w-5"/> Inventory Rebalancing Optimizer</h2>
                        <button 
                            onClick={handleOptimize} 
                            disabled={optimizing} 
                            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition font-medium shadow-md disabled:opacity-50"
                        >
                            {optimizing ? "Calculating..." : "Run Optimization"}
                        </button>
                    </div>
                    
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-800 italic mb-4">
                        <span className="font-bold">Gemini Action:</span> {rebalanceExplanation}
                    </div>

                    {rebalancePlan && rebalancePlan.length > 0 ? (
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                {rebalancePlan.map((transfer, idx) => (
                                    <motion.div 
                                        key={idx} 
                                        initial={{ scale: 0.95, opacity: 0 }} 
                                        animate={{ scale: 1, opacity: 1 }} 
                                        transition={{ delay: idx * 0.1 }} 
                                        className="bg-white border border-gray-100 p-4 rounded-lg flex flex-col items-center text-center shadow-sm hover:shadow-md transition duration-200"
                                    >
                                        <div className="text-3xl mb-2 text-green-600">➡️</div>
                                        <div className="font-bold text-gray-800">Transfer #{idx + 1}</div>
                                        <div className="text-sm text-gray-600 my-2">Move <span className="font-bold text-black">{Math.round(transfer.amount)} units</span></div>
                                        <div className="text-xs font-mono bg-gray-100 px-3 py-1 rounded border border-gray-200 text-gray-700 w-full truncate">{transfer.from} ➡️ {transfer.to}</div>
                                    </motion.div>
                                ))}
                            </div>
                        ) : (
                            <div className="text-center py-8 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
                                <p className="text-gray-400">No transfers suggested by the Optimization Engine.</p>
                            </div>
                        )}
                </div>
            </div>
        </div>
    );
}