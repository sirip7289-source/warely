import React, { useState, useEffect } from 'react';
import { PackagePlus, RefreshCw, Warehouse, Box, Search, Filter, ArrowRight } from 'lucide-react';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

interface SKU { id: number; name: string; category: string; unit_price: number; }
interface Warehouse { id: number; name: string; location: string; capacity: number; }
interface InventoryItem { warehouse: string; sku: string; quantity: number; }

export default function InventoryPage() {
    const [inventory, setInventory] = useState<InventoryItem[]>([]);
    const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
    const [skus, setSkus] = useState<SKU[]>([]);
    const [loading, setLoading] = useState(true);

    // Fetch function (Simplified for brevity - keeps your logic)
    const fetchData = async () => {
        setLoading(true);
        try {
            const [inv, wh, sk] = await Promise.all([
                fetch(`${API_URL}/inventory/levels`).then(r => r.json()),
                fetch(`${API_URL}/inventory/warehouses`).then(r => r.json()),
                fetch(`${API_URL}/inventory/skus`).then(r => r.json())
            ]);
            setInventory(inv); setWarehouses(wh); setSkus(sk);
        } catch (e) { console.error(e); } 
        finally { setLoading(false); }
    };

    useEffect(() => { fetchData(); }, []);

    // -- Handlers (Keep your existing handlers here) -- 
    // For UI demo purposes, I am linking the UI elements below.
    
    return (
        <div className="space-y-8 animate-fade-in">
            
            {/* Header Actions */}
            <div className="flex justify-between items-end">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">Inventory Management</h1>
                    <p className="text-slate-500 mt-1">Track stock levels, create SKUs, and manage warehouses.</p>
                </div>
                <button onClick={fetchData} className="btn-secondary text-xs gap-2">
                    <RefreshCw size={16} className={loading ? "animate-spin" : ""} /> Refresh Data
                </button>
            </div>

            {/* Section 1: Actions Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Stock Adjustment Card */}
                <div className="glass-card p-6 lg:col-span-3 border-l-4 border-indigo-500">
                    <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                        <PackagePlus className="text-indigo-500" size={20}/> 
                        Quick Stock Adjustment
                    </h3>
                    <form className="flex flex-col md:flex-row gap-4 items-end">
                        <div className="flex-1 w-full">
                            <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Select SKU</label>
                            <select className="input-field cursor-pointer">
                                <option>Select Product...</option>
                                {skus.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                            </select>
                        </div>
                        <div className="flex-1 w-full">
                            <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Warehouse</label>
                            <select className="input-field cursor-pointer">
                                <option>Select Location...</option>
                                {warehouses.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
                            </select>
                        </div>
                        <div className="w-full md:w-48">
                            <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Change Qty</label>
                            <input type="number" placeholder="+/-" className="input-field" />
                        </div>
                        <button className="btn-primary w-full md:w-auto h-[46px]">
                            Update Stock
                        </button>
                    </form>
                </div>

                {/* Create Warehouse */}
                <div className="glass-card p-6">
                    <h3 className="text-base font-semibold text-slate-800 mb-4 flex items-center gap-2">
                        <Warehouse className="text-slate-400" size={18}/> New Warehouse
                    </h3>
                    <div className="space-y-3">
                        <input type="text" placeholder="Name (e.g. East Hub)" className="input-field" />
                        <input type="text" placeholder="Location" className="input-field" />
                        <input type="number" placeholder="Capacity" className="input-field" />
                        <button className="btn-secondary w-full mt-2 text-indigo-600 border-indigo-100 hover:bg-indigo-50">Create Location</button>
                    </div>
                </div>

                {/* Create SKU */}
                <div className="glass-card p-6">
                    <h3 className="text-base font-semibold text-slate-800 mb-4 flex items-center gap-2">
                        <Box className="text-slate-400" size={18}/> New Product (SKU)
                    </h3>
                    <div className="space-y-3">
                        <input type="text" placeholder="SKU Name" className="input-field" />
                        <div className="flex gap-3">
                            <input type="text" placeholder="Category" className="input-field" />
                            <input type="number" placeholder="Price" className="input-field" />
                        </div>
                        <button className="btn-secondary w-full mt-2 text-indigo-600 border-indigo-100 hover:bg-indigo-50">Create SKU</button>
                    </div>
                </div>
            </div>

            {/* Section 2: Data Table */}
            <div className="glass-card overflow-hidden">
                <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                    <h3 className="font-semibold text-slate-700">Current Holdings</h3>
                    <div className="flex gap-2">
                        <div className="relative">
                            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
                            <input type="text" placeholder="Search stock..." className="pl-9 pr-4 py-1.5 text-sm border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500" />
                        </div>
                        <button className="p-2 text-slate-500 hover:bg-slate-100 rounded"><Filter size={16}/></button>
                    </div>
                </div>
                
                <table className="w-full text-left border-collapse">
                    <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-semibold tracking-wider">
                        <tr>
                            <th className="px-6 py-4">Product / SKU</th>
                            <th className="px-6 py-4">Warehouse Location</th>
                            <th className="px-6 py-4 text-right">Status</th>
                            <th className="px-6 py-4 text-right">Quantity</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {inventory.length === 0 ? (
                             <tr><td colSpan={4} className="p-8 text-center text-slate-400">No data available.</td></tr>
                        ) : (
                            inventory.map((item, idx) => (
                                <tr key={idx} className="hover:bg-slate-50 transition-colors">
                                    <td className="px-6 py-4 font-medium text-slate-700">{item.sku}</td>
                                    <td className="px-6 py-4 text-slate-500 flex items-center gap-2">
                                        <div className="w-2 h-2 rounded-full bg-slate-300"></div>
                                        {item.warehouse}
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                            item.quantity < 50 ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
                                        }`}>
                                            {item.quantity < 50 ? 'Low Stock' : 'In Stock'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-right font-mono text-slate-600">{item.quantity}</td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}