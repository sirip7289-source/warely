import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { UploadCloud, CheckCircle, XCircle } from 'lucide-react';

// NOTE: We assume this page is only for analysis/logging. 
// To update stock from here, you'd need to add the stock update logic 
// from InventoryPage, which is complex and outside the initial scope for this file.

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

export default function UploadPage() {
    const [file, setFile] = useState<File | null>(null);
    const [result, setResult] = useState<any>(null);
    const [loading, setLoading] = useState(false);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files ? e.target.files[0] : null;
        setFile(selectedFile);
        if (selectedFile) {
            setPreviewUrl(URL.createObjectURL(selectedFile));
        } else {
            setPreviewUrl(null);
        }
        setResult(null); // Clear previous result
    };

    const handleUpload = async () => {
        if (!file) return;
        setLoading(true);
        const formData = new FormData();
        formData.append('file', file);

        try {
            const res = await fetch(`${API_URL}/upload/photo`, {
                method: 'POST',
                body: formData,
            });
            const data = await res.json();
            setResult(data);
        } catch (err) {
            console.error(err);
            setResult({ error: "Failed to connect to AI service. Check API key and backend logs." });
        }
        setLoading(false);
    };

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-gray-800 flex items-center border-b pb-2"><UploadCloud className="mr-3"/> Incoming Stock Photo Analysis</h1>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Upload Section */}
                <div className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-blue-500">
                    <h2 className="text-xl font-semibold mb-4 text-blue-700">1. Select Image for Scanning</h2>
                    
                    <input 
                        type="file" 
                        onChange={handleFileChange}
                        accept="image/jpeg, image/png"
                        className="mb-6 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                    />

                    {previewUrl && (
                        <div className="mb-6 p-4 border rounded-lg bg-gray-50">
                            <h3 className="text-sm font-medium mb-2">Image Preview:</h3>
                            <img src={previewUrl} alt="Stock Preview" className="max-w-full h-auto rounded-lg shadow-md" style={{ maxHeight: '300px', objectFit: 'contain' }}/>
                        </div>
                    )}
                    
                    <button 
                        onClick={handleUpload}
                        className="bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 w-full transition font-medium disabled:opacity-50"
                        disabled={loading || !file}
                    >
                        {loading ? "Analyzing with Gemini..." : "Upload & Run Vision Analysis"}
                    </button>
                </div>

                {/* Results Section */}
                <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-purple-500"
                >
                    <h2 className="text-xl font-semibold mb-4 text-purple-700">2. AI Extracted Data</h2>
                    
                    {result === null && !loading ? (
                        <p className="text-gray-500 py-12 text-center">Upload an image to start the AI analysis pipeline.</p>
                    ) : result?.error ? (
                        <CustomAlert message={result.error} type="error" />
                    ) : result?.detected_sku ? (
                        <div className="space-y-4">
                            <div className={`p-4 rounded-lg flex items-center space-x-3 ${result.is_damaged ? "bg-red-100 text-red-800 border-l-4 border-red-500" : "bg-green-100 text-green-800 border-l-4 border-green-500"}`}>
                                {result.is_damaged ? <XCircle size={24} /> : <CheckCircle size={24} />}
                                <p className="font-bold">{result.is_damaged ? "⚠️ ITEM DAMAGED" : "✅ ITEM APPROVED"}</p>
                            </div>

                            <div className="grid grid-cols-2 gap-4 border p-4 rounded-lg">
                                <div><span className="text-xs text-gray-500 uppercase font-bold">Detected SKU</span><p className="text-lg font-bold text-gray-900">{result.detected_sku}</p></div>
                                <div><span className="text-xs text-gray-500 uppercase font-bold">Quantity Count</span><p className="text-lg font-bold text-gray-900">{result.detected_qty}</p></div>
                                <div><span className="text-xs text-gray-500 uppercase font-bold">Expiry Date (OCR)</span><p className="text-lg font-bold text-gray-900">{result.expiry_date || 'N/A'}</p></div>
                                <div><span className="text-xs text-gray-500 uppercase font-bold">Damage Score</span><p className="text-lg font-bold text-gray-900">{result.damage_score || '0.0'}</p></div>
                            </div>
                            
                            <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-700 italic">
                                <span className="font-bold text-black">Gemini Summary:</span> {result.ai_explanation}
                            </div>
                        </div>
                    ) : (
                        <p className="text-gray-500 py-12 text-center">Results will appear here after analysis.</p>
                    )}
                </motion.div>
            </div>
        </div>
    );
}

// Reusable Alert component (for UploadPage use)
const CustomAlert: React.FC<{ message: string, type: 'success' | 'error' | 'info' }> = ({ message, type }) => {
    const baseStyle = "p-4 rounded-lg font-medium mb-4";
    let colorStyle = "";
    if (type === 'success') colorStyle = "bg-green-100 text-green-800 border-l-4 border-green-500";
    if (type === 'error') colorStyle = "bg-red-100 text-red-800 border-l-4 border-red-500";
    if (type === 'info') colorStyle = "bg-blue-100 text-blue-800 border-l-4 border-blue-500";
    
    return message ? <div className={`${baseStyle} ${colorStyle}`}>{message}</div> : null;
};